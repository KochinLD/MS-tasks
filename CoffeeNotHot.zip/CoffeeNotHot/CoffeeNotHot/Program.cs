﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeNotHot
{
    internal class Program
    {
        const int t0 = 83;
        const double kf = 0.087;
        const int T_E = 20;
        const int tn = 45;
        const double dt = 0.1;
        const int milkt = 7;


        static double coffetemp(double temp)
        {
            //=Предыдущее значение-kf*(предыдущее значение-T_E)*dt
            return temp - kf*(temp-T_E)*dt;
        }

        static double addmilk(double milktemp, int milksize, double ctemp, int coffeesize)
        {
            return (ctemp * coffeesize + milksize * milktemp) / (milksize + coffeesize); 
        }


        static void Main(string[] args)
        {



            double temp = t0;
            double time = 0;
            double milkaddtime;



            Console.Write("Введите кол-во кофе: ");
            int coffeeml = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите кол-во молока: ");
            int milkml = Convert.ToInt32(Console.ReadLine());
            if(milkml == 0) 
            {
                while(temp >= tn)
                {
                    temp = coffetemp(temp);
                    time += dt;
                }
                Console.WriteLine($"Кофе без молока достигнет температуры {Math.Round(temp, 3)} через {Math.Round(time, 1)} моментов времени");
                Console.ReadLine();
                return;
            }
            else
            {
                Console.Write("Когда добавить молоко: ");
                milkaddtime = Convert.ToDouble(Console.ReadLine());
                while(Math.Round(time,1) < Math.Round(milkaddtime, 1))
                {
                    time += dt;
                    temp = coffetemp(temp);
                }
                temp = addmilk(milkt, milkml, temp, coffeeml);
                Console.WriteLine($"Температура после добавления молока стала {Math.Round(temp,3)}");
                if(temp <= tn)
                {
                    Console.WriteLine($"Кофе с молоком достигнет температуры {Math.Round(temp, 3)} через {Math.Round(time, 1)} моментов времени");
                    Console.ReadLine();
                    return;
                }
                else
                {
                    while (temp >= tn)
                    {
                        temp = coffetemp(temp);
                        time += dt;
                    }
                    Console.WriteLine($"Кофе с молоком достигнет температуры {Math.Round(temp, 3)} через {Math.Round(time,1)} моментов времени");
                    Console.ReadLine();
                    return;
                }
            }
        }

    }
}
